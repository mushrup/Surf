#!/usr/bin/env python
from pprint import pprint as pp
from flask import Flask, flash, redirect, render_template, request, url_for, jsonify
from handle_query import query_api
from sqlConnector import connect_with_connector,update_with_connector
from FindWaves import ordinates_to_latlong
#import sqlalchemy

app = Flask(__name__)

@app.route('/', methods=['GET','POST'])
def index():
    """ Initializes a Unix socket connection pool for a Cloud SQL instance of MySQL. """
    # Note: Saving credentials in environment variables is convenient, but not
    # secure - consider a more secure solution such as
    # Cloud Secret Manager (https://cloud.google.com/secret-manager) to help
    # keep secrets safe.
    if request.method == 'POST':
        user_name = request.form.get('user-name')
        comments = request.form.get('comment')
        update_with_connector(user_name,comments,"comments")
    df = connect_with_connector("comments")
    name_list = df['user_name'].values
    comment_list = df['comments'].values
    time_list = df['time'].values
    name_comment_list = list(map(list, zip(name_list, comment_list, time_list)))
    return render_template(
        'index.html',
        tables=name_comment_list,
        titles=df.columns.values)

@app.route("/result" , methods=['GET', 'POST'])
def result():
    
    user_name = request.form.get('user-name')
    spot_name = request.form.get('spot-name')
    comments = request.form.get('comment')
    spot_list0 = request.form.get('spot-list0')
    spot_list1 = request.form.get('spot-list1')
    spot_list2 = request.form.get('spot-list2')
    spot_list3 = request.form.get('spot-list3')
    spot_list4 = request.form.get('spot-list4')
    spot_list5 = request.form.get('spot-list5')
    spot_list6 = request.form.get('spot-list6')
    spot_list7 = request.form.get('spot-list7')
    spot_list8 = request.form.get('spot-list8')
    spot_list9 = request.form.get('spot-list9')
    spot_list = [spot_list0,spot_list1,spot_list2,spot_list3,spot_list4,
    spot_list5,spot_list6,spot_list7,spot_list8,spot_list9]
    spot_list = [i for i in spot_list if i is not None]
    print("spot_list:")
    print(spot_list)
    lat = request.form.get('inputBoxLat')
    long = request.form.get('inputBoxLong')
    if lat == None and long == None:
        data = []
        table_list = []
        error = None
        if spot_list != None:
            resp = {'gis_ls':[]}
            if spot_name != None:
                print(
                    "cp1"
                )
                table_name = spot_name            
                update_with_connector(user_name,comments,table_name) 
            for spot_unit in spot_list:
                print(
                    "cp2"
                )
                df = connect_with_connector(spot_unit)
                name_list = df['user_name'].values
                comment_list = df['comments'].values
                time_list = df['time'].values
                name_comment_list = list(map(list, zip(name_list, comment_list, time_list)))
                table_list.append(name_comment_list)
                print(table_list)
                x = int(spot_unit.split('_')[0])
                y = int(spot_unit.split('_')[1])
                (lat,long) = ordinates_to_latlong((x,y))
                resp['gis_ls'].append({'gmap_url_embed': 'https://maps.google.com/maps?q='+str(lat)+','+str(long)+'&z=16&t=k&output=embed&amp;iwloc=near',
                'x': str(x),
                'y': str(y)})
            data.append(resp)
            print(resp)
        return render_template(
            'result.html',
            data=data,
            tables=table_list,
            error=error)
    if lat != None and long != None:
        print("looking for waves...")
        data = []
        error = None
        if lat == '':
            lat = -8.295809974203058
        if long == '':
            long = 116.15283458296483
        resp = query_api(float(lat),float(long))
        pp(resp)
        table_list = []
        for i in resp['gis_ls']:        
            df = connect_with_connector(i['x']+'_'+i['y'])
            name_list = df['user_name'].values
            comment_list = df['comments'].values
            time_list = df['time'].values
            name_comment_list = list(map(list, zip(name_list, comment_list, time_list)))
            table_list.append(name_comment_list)
        print(table_list)
        if resp:
            data.append(resp)
        return render_template(
            'result.html',
            data=data[0:10],
            tables=table_list[0:10],
            error=error)


if __name__=='__main__':
    app.run(debug=True)


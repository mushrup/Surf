from datetime import datetime
import os
import pytz
import requests
import math
from FindWaves import Find_Waves,latlong_to_ordinates,ordinates_to_latlong

def query_api(lat,long):
    try:
        print("Start looking for waves.")
        print(str(lat)+', '+str(long))
        data = {}
        data["lat"] = lat;
        data["long"] = long;
        x_y = latlong_to_ordinates((lat,long))
        data['x'] = str(x_y[0])
        data['y'] = str(x_y[1])
        gis_ls = Find_Waves(lat,long)
        for gis in gis_ls:
          gis['lat'],gis['long'] = ordinates_to_latlong((int(gis['x']),int(gis['y'])))
          gis['gmap_url'] = 'https://www.google.com/maps?z=16&t=k&q='+str(gis['lat'])+','+str(gis['long'])
          gis['gmap_url_embed'] = 'https://maps.google.com/maps?q='+str(gis['lat'])+','+str(gis['long'])+'&z=16&t=k&output=embed&amp;iwloc=near'

        data['gis_ls'] = gis_ls
    except Exception as exc:
        print(exc)
        data = None
    return data

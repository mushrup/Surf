import requests
import cv2
import numpy as np
from numpy import inf
from math import pi, log, tan, floor, exp, atan
import decimal
from statistics import mode, mean
from random import uniform
from math import cos, sin, sqrt
import pandas as pd
import random
from PIL import Image
from queue import Queue
from threading import Thread


decimal.getcontext().prec = 20
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}

x = 206988
y = 129893
x_Desaru = 206988
y_Desaru = 129893
x_BtBl = 214903
y_BtBl = 137399
x_false = 214907
y_false = 137399
gis_ls = []

def detect_labels(path):
    """Detects labels in the file."""
    from google.cloud import vision
    import io
    client = vision.ImageAnnotatorClient()

    image = Image.open(requests.get(path, stream=True, headers=headers).raw)
    image = np.float32(image)
    bridge = cv2.imencode('.jpg', image)[1].tostring()
    image = vision.Image(content=bridge)
    response = client.label_detection(image=image)
    labels = response.label_annotations
    label_des_ls = []
    
    for label in labels:
        label_des_ls.append(label.description)
    
    if response.error.message:
        raise Exception(
            '{}\nFor more info on error messages, check: '
            'https://cloud.google.com/apis/design/errors'.format(
                response.error.message))
    
    return label_des_ls

def latlong_to_ordinates(latitude_longitude):

    # 18 is the zoom level 
    mapWidth    = pow(2,18)
    mapHeight   = pow(2,18)
    x = (latitude_longitude[1]+180)*(mapWidth/360)
    latRad = latitude_longitude[0]*pi/180
    mercN = log(tan((pi/4)+(latRad/2)))
    y = (mapHeight/2)-(mapWidth*mercN/(2*pi))
    
    return (floor(x),floor(y))
    
def ordinates_to_latlong(x_y):

    # 18 is the zoom level 
    mapWidth    = pow(2,18)
    mapHeight   = pow(2,18)
    longitude = x_y[0]/(mapWidth/360) - 180
    latitude = (atan(exp(((mapHeight/2) - x_y[1] ) * (2*pi) / mapWidth)) - (pi/4))*2/pi*180
    
    return (latitude, longitude)

def get_random_point_on_oval(lat1,long1,lat2,long2):
    x1,y1 = latlong_to_ordinates((lat1, long1))
    x2,y2 = latlong_to_ordinates((lat2, long2))
    w = x2-x1
    h = y2-y1
    x_c = (x1+x2)/2
    y_c = (y1+y2)/2
    theta = uniform(0,2*pi)
    l = uniform(sqrt((h*h*w*w)/(4*h*h*cos(theta)*cos(theta) + 4*w*w*sin(theta)*sin(theta)))*0.5,sqrt((h*h*w*w)/(4*h*h*cos(theta)*cos(theta) + 4*w*w*sin(theta)*sin(theta))))
    x_r = int(cos(theta)*l + x_c)
    y_r = int(sin(theta)*l + y_c)
    (lat,long) = ordinates_to_latlong((x_r,y_r))
    print('https://www.google.com/maps?z=16&t=k&q='+str(lat)+','+str(long))
    return (x_r,y_r)

def Get_Coast_Line(x,y,sensitivity,kernel_size,sobel_ksize,kernel_size_2):
    
    # Get Image according to x and y
    url = 'https://khms1.google.com/kh/v=941?x='+str(x)+'&y='+str(y)+'&z='+str(6)
    img = Image.open(requests.get(url, stream=True, headers=headers).raw)
    img = np.float32(img)
    img_org = img.copy()
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'.png',img)
    
    # Highlight the white part for wave detection. Sensitivity is to set up the range of whiteness
    sensitivity = sensitivity
    img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    H = img[:, :, 0]
    S = img[:, :, 1]
    V = img[:, :, 2]
    print(np.max(H),np.max(S),np.max(V))
    
    lower_white = np.array([0,0,0])
    upper_white = np.array([50,1,255])
    
    mask = cv2.inRange(img, lower_white, upper_white)
    whitened = cv2.bitwise_and(img,img, mask= mask)
    whitened = cv2.cvtColor(whitened, cv2.COLOR_HSV2BGR)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_whitened.png',whitened)
    
    # Greyscale the image
    gray = cv2.cvtColor(whitened,cv2.COLOR_BGR2GRAY)
    ret,gray = cv2.threshold(gray,10,255,cv2.THRESH_BINARY_INV)
    
    # Gaussian Blur the grayscale for edge detection. kernel_size is to set up the sharpness of the transformed
    kernel_size = kernel_size
    blur_gray = cv2.GaussianBlur(gray,(kernel_size, kernel_size),0)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_blurred.png',blur_gray)
    
    # Detect edges, output a bridge file 'sobelxy.png' meanwhile for QC. sobel_ksize is the kernal size for sobel
    sobel_ksize = sobel_ksize
    sobelxy = cv2.Sobel(blur_gray, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=sobel_ksize)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_sobelxy.png',sobelxy)
    
    # Gaussian Blur the second time to make sure edges are not super adjacent
    kernel_size_2 = kernel_size_2
    blur_gray_2 = cv2.GaussianBlur(sobelxy,(kernel_size_2, kernel_size_2),0)
    
    image_ = cv2.convertScaleAbs(gray)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_sobelxy_blurred.png',image_)
    
    #image_ = cv2.cvtColor(image_,cv2.COLOR_BGR2GRAY)
    
    contours, hierarchy = cv2.findContours(image_, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnt_lst = []
    for cnt in contours:
         if cv2.arcLength(cnt, True) > 1:
            cv2.drawContours(img, cnt, -1, (0, 255, 0), 1)
            cnt_lst = cnt_lst + merge(cnt[:, :, 0].tolist(),cnt[:, :, 1].tolist())
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_result.png',img)
    return cnt_lst

def merge(list1, list2):
     
    merged_list = [(list1[i][0], list2[i][0]) for i in range(0, len(list1))]
    return merged_list

def Count_Wave(x,y,zoom,sensitivity,kernel_size,sobel_ksize,kernel_size_2,wv_length_thrshld_min):
    
    global headers
    
    # Get Image according to x and y
    url = 'https://khms1.google.com/kh/v=941?x='+str(x)+'&y='+str(y)+'&z='+str(zoom) 

    img = Image.open(requests.get(url, stream=True, headers=headers).raw)
    img = np.float32(img)
    img_org = img.copy()
    
    # Calculate the total number of random elements on the original image
    element_count = 10
    
    try:
        gray_org = cv2.cvtColor(img_org,cv2.COLOR_BGR2GRAY)
        ret_org, bin_img_org = cv2.threshold(gray_org, 127, 255, cv2.THRESH_BINARY)
        blur_bin_org = cv2.GaussianBlur(bin_img_org,(kernel_size, kernel_size),0)
        blur_bin_org = cv2.normalize(blur_bin_org, None, 255, 0, cv2.NORM_MINMAX, cv2.CV_8U)
        contours_full_color, hierarchy_full_color = cv2.findContours(blur_bin_org, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) 
        element_count = len(contours_full_color)
    except:
        element_count = 0
        print("element_count = 0")
    
    # Highlight the white part for wave detection. Sensitivity is to set up the range of whiteness
    sensitivity = sensitivity
    img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    H = img[:, :, 0]
    img[:, :, 1] = img[:, :, 1]*225
    S = img[:, :, 1]
    V = img[:, :, 2]
    print(np.min(S))
    if np.average(H) > 170 or np.average(H) < 50:
        return {'x':x,'y':y,'wv_count':0,'estimate':False}
    lower_white = np.array([0,0,200])
    upper_white = np.array([360,30,255])
    
    mask = cv2.inRange(img, lower_white, upper_white)
    whitened = cv2.bitwise_and(img,img, mask= mask)
    whitened[:, :, 1] = whitened[:, :, 1]/225
    whitened = cv2.cvtColor(whitened, cv2.COLOR_HSV2BGR)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_whitened.png',whitened)
    
    # Greyscale the image
    gray = cv2.cvtColor(whitened,cv2.COLOR_BGR2GRAY)
    
    # Gaussian Blur the grayscale for edge detection. kernel_size is to set up the sharpness of the transformed
    kernel_size = kernel_size
    blur_gray = cv2.GaussianBlur(gray,(kernel_size, kernel_size),0)
    
    # Detect edges, output a bridge file 'sobelxy.png' meanwhile for QC. sobel_ksize is the kernal size for sobel
    sobel_ksize = sobel_ksize
    sobelxy = cv2.Sobel(blur_gray, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=sobel_ksize)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_sobelxy.png',sobelxy)
    
    # Gaussian Blur the second time to make sure edges are not super adjacent
    kernel_size_2 = kernel_size_2
    blur_gray_2 = cv2.GaussianBlur(sobelxy,(kernel_size_2, kernel_size_2),0)
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_sobelxy_blurred_twice.png',blur_gray_2)
    
    # Find contours to count waves, wv_length_thrshld is to make sure contour perimeter has to be at least (most) x (y) amount to be counted as a wave and wv_area_length_ratio is to make sure the contour is flat-shaped
    #image = cv2.imread('images/'+str(x)+'-'+str(y)+'_sobelxy_blurred_twice.png',0)
    
    image_ = cv2.convertScaleAbs(blur_gray_2)
    #image_ = cv2.cvtColor(image_,cv2.COLOR_BGR2GRAY)
    
    ret, bin_img = cv2.threshold(image_, 127, 255, cv2.THRESH_BINARY)    
    wv_count = 0
    rho = 50 # distance resolution in pixels of the Hough grid
    theta = np.pi / 180 # angular resolution in radians of the Hough grid
    threshold = 5  # minimum number of votes (intersections in Hough grid cell)
    min_line_length = wv_length_thrshld_min / 2  # minimum number of pixels making up a line
    max_line_gap = 2  # maximum gap in pixels between connectable line segments
    line_image = np.copy(img) * 0  # creating a blank to draw lines on
    lines = cv2.HoughLinesP(bin_img, rho, theta, threshold, np.array([]),
                    min_line_length, max_line_gap)
           
    # element_count has to be low enough as waves can only be found on a simple shore;
    # and total whiteness after sharpenning the edge and blurring cant be too be too much
    # and at least 2 lines found
    temp_lines_lst = []
    for line in lines:
        for x1,y1,x2,y2 in line:
            if sqrt((x1-x2)**2+(y1-y2)**2)>30:
                temp_lines_lst.append(line)
                image = cv2.line(img_org,(x1,y1),(x2,y2),(217,116,43),2)
    lines = temp_lines_lst
    if lines is not None and len(lines) >= 2 and element_count < 25 and element_count > 0 and np.sum(blur_gray_2 > 0) < 15000 and np.sum(blur_gray_2 > 0) > 3000:
        # Lines are roughly in the same direction
        k_ls = []
        for line in lines:
            for x1,y1,x2,y2 in line:
                k_ls.append(round(atan((y2-y1)/(x2-x1)),1))
        try:
            k_concentration_ratio = np.sum(abs(np.array(k_ls)-mode(np.array(k_ls)))<=pi/6)/len(k_ls)
        except:
            k_concentration_ratio = np.sum(abs(np.array(k_ls)-mean(np.array(k_ls)))<=pi/6)/len(k_ls)
        print(k_concentration_ratio)
        if k_concentration_ratio >= 0.5:
            label_ls = detect_labels(url)
            if 'Water' in label_ls and 'City' not in label_ls:
                print(label_ls)
                wv_count = len(lines)
                print("Eureka!")
                    
    #cv2.imwrite('images/'+str(x)+'-'+str(y)+'_result.png',image)
    if wv_count > 0:
        return {'x':str(x),'y':str(y),'wv_count':wv_count,'estimate':True}
    else:
        return {'x':str(x),'y':str(y),'wv_count':0,'estimate':False}

def latlong_to_ordinates_enlarged(latitude_longitude):

    # 6 is the zoom level 
    mapWidth    = pow(2,6)
    mapHeight   = pow(2,6)
    x = (latitude_longitude[1]+180)*(mapWidth/360)
    latRad = latitude_longitude[0]*pi/180
    mercN = log(tan((pi/4)+(latRad/2)))
    y = (mapHeight/2)-(mapWidth*mercN/(2*pi))
    
    return (floor(x),floor(y))

def ordinates_to_latlong_enlarged(x_y):

    # 6 is the zoom level 
    mapWidth    = pow(2,6)
    mapHeight   = pow(2,6)
    longitude = x_y[0]/(mapWidth/360) - 180
    latitude = (atan(exp(((mapHeight/2) - x_y[1] ) * (2*pi) / mapWidth)) - (pi/4))*2/pi*180
    
    return (latitude, longitude)

def Find_Waves(lat,long):
    gis_ls = []
    i = 0
    input_latlong = (lat, long)
    (x_start , y_start) = latlong_to_ordinates_enlarged(input_latlong)
    coast_lst = Get_Coast_Line(x_start , y_start,sensitivity=60,kernel_size=5,sobel_ksize=5,kernel_size_2=5)
    
    def do_stuff(q):
        while True:
            try: 
                x,y = q.get()
                gis = Count_Wave(x,y,zoom=18,sensitivity=60,kernel_size=5,sobel_ksize=5,kernel_size_2=5,wv_length_thrshld_min=60)
                if gis['estimate'] == True:
                    gis_ls.append(gis)
            except Exception as e:
                print(e)
                pass
            q.task_done()

    q = Queue(maxsize=0)
    num_threads = 200

    for i in range(num_threads):
        worker = Thread(target=do_stuff, args=(q,))
        worker.setDaemon(True)
        worker.start()

    ls = random.sample(coast_lst,min(200,len(coast_lst)))
    ls_new = []
    for l in ls:
        random_latlong_on_coast = ordinates_to_latlong_enlarged((x_start+l[0]/256,y_start+l[1]/256))
        (x_r,y_r) = latlong_to_ordinates(random_latlong_on_coast)
        for i in range(-2,3):
            ls_new.append((x_r-i,y_r))
    for l in ls_new:
        q.put(l)

    q.join()

    gis_ls = [dict(t) for t in {tuple(d.items()) for d in gis_ls}]
        #lat,long = ordinates_to_latlong((gis['x'],gis['y']))
        #print('https://www.google.com/maps?z=16&t=k&q='+str(lat)+','+str(long))
    return gis_ls
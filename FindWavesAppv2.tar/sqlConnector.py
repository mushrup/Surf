import os

from google.cloud.sql.connector import Connector, IPTypes
import pymysql
from sqlalchemy import select,text

import pandas as pd
import sqlalchemy
from datetime import datetime

def connect_with_connector(table_name) -> sqlalchemy.engine.base.Engine:
    """
    Initializes a connection pool for a Cloud SQL instance of MySQL.

    Uses the Cloud SQL Python Connector package.
    """
    # Note: Saving credentials in environment variables is convenient, but not
    # secure - consider a more secure solution such as
    # Cloud Secret Manager (https://cloud.google.com/secret-manager) to help
    # keep secrets safe.

    db_user = 'root'
    db_pass = '15th15s@f3?'
    db_name = 'comment_system'
    instance_connection_name = 'find-surf-spots:asia-southeast1:findwaves'
    
    '''
    instance_connection_name = os.environ["INSTANCE_CONNECTION_NAME"]  # e.g. 'project:region:instance'
    db_user = os.environ.get("DB_USER", "")  # e.g. 'my-db-user'
    db_pass = os.environ["DB_PASS"]  # e.g. 'my-db-password'
    db_name = os.environ["DB_NAME"]  # e.g. 'my-database'
    '''
    ip_type = IPTypes.PUBLIC

    connector = Connector(ip_type)

    def getconn() -> pymysql.connections.Connection:
        conn: pymysql.connections.Connection = connector.connect(
            instance_connection_name,
            "pymysql",
            user=db_user,
            password=db_pass,
            db=db_name,
        )
        return conn

    engine = sqlalchemy.create_engine(
        "mysql+pymysql://",
        creator=getconn,
        # ...
    )
    with engine.begin() as conn:
        try:
            query = text("CREATE TABLE "+table_name+"(user_name nvarchar(20),comments text,time nvarchar(30));")
            conn.execute(query)
        except:
            pass
        finally:
            query = text("SELECT * FROM "+table_name)
            df = pd.read_sql_query(query, conn)
    print(df)
    return df

def update_with_connector(user_name,comments,table_name) -> sqlalchemy.engine.base.Engine:
    """
    Initializes a connection pool for a Cloud SQL instance of MySQL.

    Uses the Cloud SQL Python Connector package.
    """
    # Note: Saving credentials in environment variables is convenient, but not
    # secure - consider a more secure solution such as
    # Cloud Secret Manager (https://cloud.google.com/secret-manager) to help
    # keep secrets safe.

    db_user = 'root'
    db_pass = '15th15s@f3?'
    db_name = 'comment_system'
    instance_connection_name = 'find-surf-spots:asia-southeast1:findwaves'
    
    ip_type = IPTypes.PUBLIC

    connector = Connector(ip_type)

    def getconn() -> pymysql.connections.Connection:
        conn: pymysql.connections.Connection = connector.connect(
            instance_connection_name,
            "pymysql",
            user=db_user,
            password=db_pass,
            db=db_name,
        )
        return conn

    engine = sqlalchemy.create_engine(
        "mysql+pymysql://",
        creator=getconn,
        # ...
    )
    with engine.begin() as conn:
        time = datetime.now().strftime('%m/%d/%Y %H:%M')
        print(user_name,comments,time)
        query = text("INSERT INTO "+table_name+" VALUES (:user_name,:comments,:time);")
        result = conn.execute(query,{"user_name": user_name, "comments": comments, "time": time})
    return